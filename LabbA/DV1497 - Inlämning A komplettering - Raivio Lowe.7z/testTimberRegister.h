//Lowe Raivio
#ifndef TEST_TIMBERS_REGISTER_H
#define TEST_TIMBERS_REGISTER_H

#include <iostream>

void testFunction();

#endif // !TEST_TIMBERS_REGISTER_H
