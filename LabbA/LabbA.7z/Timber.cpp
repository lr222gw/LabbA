//Lowe Raivio
#include "Timber.h"

void Timber::setPrice(float price)
{
	this->prisPerMeter = price;
}

void Timber::setMeter(float meter)
{
	this->antalMeter = meter;
}

float Timber::getPrice()
{
	
	return this->prisPerMeter*this->antalMeter;
	
}

Timber::Timber(float width, float height, float meters, float prisPerMeter)
{
	this->height = height;
	this->width = width;
	this->antalMeter = meters;
	this->dimension = to_string((int)width) + "x" + to_string((int)height);
	this->prisPerMeter = prisPerMeter;
	
}

Timber::Timber()
{// Konstruktor
	this->antalMeter = -1;
	this->dimension = "null";
	this->prisPerMeter = -1;	
	this->height = -1;
	this->width = -1;

}

string Timber::toString()
{
	string myString =	this->dimension + "| " +
						to_string(this->antalMeter) + " | " +
						to_string(this->height) + " | " +
						to_string(this->width);
	return myString;
}

string Timber::getDimension()
{
	return this->dimension;
}

float Timber::getMeter()
{
	return this->antalMeter;
}

float Timber::getPricePerMeter()
{
	return this->prisPerMeter;
}


Timber::Timber(const Timber& copy)
{

	this->antalMeter = copy.antalMeter;
	this->dimension = copy.dimension;

	this->prisPerMeter = copy.prisPerMeter;

	this->height = copy.height;
	this->width = copy.width;
}

bool Timber::operator==(const Timber & other)
{	
	
	return (this->dimension == other.dimension);

}