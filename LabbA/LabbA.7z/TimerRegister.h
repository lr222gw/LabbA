//Lowe Raivio
#ifndef TIMBER_REGISTER_H
#define TIMBER_REGISTER_H

#include <string>
#include "Timber.h"

using namespace std;

class TimberRegister{
private:
	int capacity;
	int TimbersInArr;
	Timber ** timberArr;
	void expandTimberArr();

public:

	void editTimber(string dimension, float newPrice, float newMeter);

	void getTimber(string dimension, Timber &timberToGet);

	float amountOfCash();

	void saveFile(string fileName);

	bool exists(Timber toCheck);

	void add(Timber toAdd);

	TimberRegister();
	TimberRegister(int capacity);
	~TimberRegister(); 

	string *getTimberStringArr(float min = -1); // "-1" betyder skit i att j�mf�ra...

	void removeTimber(string dimension);

	int getTimbersAmount();

	TimberRegister &operator=(const TimberRegister & other); //Tilldelnignskonstruktor

	

	string TimberToString();//Ska g� igenom alla i TimbersArr och sedan l�gga dem i en StringArray som ska returneras?

	TimberRegister(const TimberRegister& copy);



};



#endif // !TIMBER_REGISTER_H
