//Lowe Raivio
#ifndef TIMBER_H
#define TIMBER_H

#include <string>

using namespace std;


class Timber {

private:
	string dimension;
	int antalMeter;
	float width;
	float height;
	float prisPerMeter;

public:

	void setPrice(float price);

	void setMeter(float meter);

	float getMeter();

	float getPricePerMeter();

	float getPrice();

	Timber(float width, float height, float meters, float prisPerMeter);

	Timber();

	string toString();

	string getDimension();
	
	bool operator==(const Timber& other);

	Timber::Timber(const Timber& copy);


};


#endif // !TIMBER_H
