//Lowe Raivio
#include "TimerRegister.h"
#include <fstream>

void TimberRegister::expandTimberArr()
{
	//OBS, kontrollera att DeepCopy har utf�rts...

	this->capacity *= 2;

	Timber **tempArr = new Timber*[this->capacity];

	for (int i = 0; i < this->TimbersInArr; i++) {
		tempArr[i] = this->timberArr[i];
	}

	delete this->timberArr;

	this->timberArr = tempArr;

	tempArr = nullptr;
}

void TimberRegister::editTimber(string dimension, float newPrice, float newMeter)
{
	for (int i = 0; i < this->getTimbersAmount(); i++) {
		if (this->timberArr[i]->getDimension() == dimension) {
			this->timberArr[i]->setPrice(newPrice);
			this->timberArr[i]->setMeter(newMeter);
		}
	}
}

void TimberRegister::getTimber(string dimension, Timber &timberToGet)
{
	
	for (int i = 0; i < this->getTimbersAmount(); i++) {
		if (this->timberArr[i]->getDimension() == dimension) {
			timberToGet = *this->timberArr[i];
		}
	}
}

float TimberRegister::amountOfCash()
{
	float money = 0; 
	{
		for (int i = 0; i < this->TimbersInArr; i++) {
			money += this->timberArr[i]->getPrice();
		}
	}
	return money;
}

void TimberRegister::saveFile(string fileName)
{

	ofstream newFile(fileName);
	if (newFile.is_open())
	{
		for (int i = 0; i < this->TimbersInArr; i++)
		{
			newFile << this->timberArr[i]->toString() << endl;
		}
	}

	newFile.close();
	
}

bool TimberRegister::exists(Timber toCheck)
{
	bool status = false;
	for (int i = 0; i < this->TimbersInArr; i++) {
		if (this->timberArr[i]->getDimension() == toCheck.getDimension()) {
			status = true;
		}
	}
	return status;
}

void TimberRegister::add(Timber toAdd)
{	

	if (!this->exists(toAdd)) {
		if (this->capacity == this->TimbersInArr) {
			this->expandTimberArr();
		}

		this->timberArr[this->TimbersInArr] = new Timber(toAdd);
		this->TimbersInArr++;
	}
	
}

TimberRegister::TimberRegister()
{
	this->capacity = 5;
	this->timberArr = new Timber*[capacity];
}

TimberRegister::TimberRegister(int capacity)
{
	this->capacity = capacity;
	this->timberArr = new Timber*[capacity];
	this->TimbersInArr = 0;
}

TimberRegister::~TimberRegister()
{
	for (int i = 0; i < this->TimbersInArr; i++) {
		delete this->timberArr[i];
	}
	
	delete[] this->timberArr;
}

string * TimberRegister::getTimberStringArr(float min)
{
	string *arr;
	if (this->TimbersInArr == 0) {
		arr = new string[1];
	}
	else {
		arr = new string[this->TimbersInArr];
	}
	

	for (int i = 0; i < this->TimbersInArr; i++) {
		if (min == -1) {
			arr[i] = this->timberArr[i]->toString();
		}
		else {
			if (min >= this->timberArr[i]->getMeter()) {
				arr[i] = this->timberArr[i]->toString();
			}
		}
		
	}

	if (this->TimbersInArr == 0) {
		arr[0] = "TimberRegister �r helt tom...\n";
	}

	return arr;
}

void TimberRegister::removeTimber(string dimension)
{
	
	for (int i = 0; i < this->TimbersInArr; i++) {
		
		if (this->timberArr[i]->getDimension() == dimension ) {

			delete this->timberArr[i];

			this->timberArr[i] = this->timberArr[this->TimbersInArr - 1];

			Timber *toAdd = new Timber();

			this->timberArr[this->TimbersInArr - 1] = toAdd;
			delete toAdd;

			this->TimbersInArr = this->TimbersInArr - 1;
		
		}
		
	}


}

int TimberRegister::getTimbersAmount()
{
	//returnera din timbersArray
	return this->TimbersInArr;
}


TimberRegister & TimberRegister::operator=(const TimberRegister &other)
{
	this->capacity = other.capacity;
	*this->timberArr = *other.timberArr;
	this->TimbersInArr = other.TimbersInArr;
	
	return *this; //? 
	// TODO: insert return statement here
}



string TimberRegister::TimberToString()
{
	//TODO:  loopa timberArr, anv�nd "toString", spara ner alla resultat, returnera stringArr
	return string();
}

TimberRegister::TimberRegister(const TimberRegister& copy)
{

	this->capacity = copy.capacity;
	this->TimbersInArr = copy.TimbersInArr;

	Timber **tempArr = new Timber*[this->capacity];

	for (int i = 0; i < this->TimbersInArr; i++) {
		tempArr[i] = copy.timberArr[i];
	}

	

	this->timberArr = tempArr;


}
